# Fake_News_Detection
A web application for detecting fake news from real ones utilizing Natural Language Processing.

This is the Flask verison, please see the other branch for the Django version.

The app is deployed on Heroku, with [link](https://fakenewsdetectorflask.herokuapp.com/).  
Feel free to use the API I published on [RapidAPI](https://rapidapi.com/fangyiyu/api/fake-news-detection1/).
